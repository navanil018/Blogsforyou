from django.contrib import admin
from django.urls import path, include
from .views import about, home
from articles.views import article_list

urlpatterns = [
    path('admin/', admin.site.urls),
    path('articles/', article_list),
    path('about/', about),
    path('', home),
]
